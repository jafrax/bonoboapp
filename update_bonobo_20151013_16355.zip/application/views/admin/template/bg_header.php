<?php
echo"
<!DOCTYPE html>
<html>
    <head>
        <meta charset='UTF-8'>
        <title>Administrator Bonobo | Dashboard</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href='".site_url("html/admin/css/bootstrap.min.css' rel='stylesheet")."' type='text/css' />
        <!-- font Awesome -->
        <link href='".site_url("html/admin/css/font-awesome.min.css")."' rel='stylesheet' type='text/css' />
        <!-- Ionicons -->
        <link href='".site_url("html/admin/css/ionicons.min.css")."' rel='stylesheet' type='text/css' />
        <!-- DATA TABLES -->
        <link href='".site_url("html/admin/css/datatables/dataTables.bootstrap.css")."' rel='stylesheet' type='text/css' />
        <!-- date picker -->
        <link href='".site_url("html/admin/css/datepicker/bootstrap-datepicker.css")."' rel='stylesheet' type='text/css' />
        <!-- Bootstrap time Picker -->
        <link href='".site_url("html/admin/css/timepicker/bootstrap-timepicker.min.css.")."' rel='stylesheet'/>
        <!-- Theme style -->
        <link href='".site_url("html/admin/css/AdminLTE.css")."' rel='stylesheet' type='text/css' />
        
        <link type='text/css' rel='stylesheet' href='".base_url("html/css/chosen.css")."' />

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script>
          <script src='https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js'></script>
        <![endif]-->
		<style type='text/css'>
			.error {
				font-style: italic !important;
				color: #E3695C !important;
				font-size: 11px !important;
				margin-top: 0px !important;
			}
		</style>
    </head>";
?>