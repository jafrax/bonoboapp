<?php
echo " form_open_multipart('daftar_toko/UploadExcel');?>
<input type='file' name='file_name' size='20' />
<br /><br />
<input type='submit' name='up' value='upload' />
</form>
";
?>