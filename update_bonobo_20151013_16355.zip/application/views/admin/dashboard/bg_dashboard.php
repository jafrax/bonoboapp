<?php
echo "
<!-- Right side column. Contains the navbar and content of the page -->
<aside class='right-side'>
	<!-- Content Header (Page header) -->
	<section class='content-header'>
		<h1>
			Dashboard
		</h1>
		<ol class='breadcrumb'>
			<li class='active'>Dashboard</li>
		</ol>
	</section>

	<!-- Main content -->
	<section class='content'>
		<h2>Selamat Datang</h2>
	</section><!-- /.content -->
</aside><!-- /.right-side -->";
?>