<?php
echo"
			</div>
		</div>
	</div>
</content>

<footer class='page-footer grey darken-3 nolmar nolpad'>
<!--		
	<div class='container'>
		<div class='row'>
			<div class='col l6 s12'>
				<h5 class='white-text'>Footer Content</h5>
				<p class='grey-text text-lighten-4'>You can use rows and columns here to organize your footer content.</p>
			</div>
		
			<div class='col l4 offset-l2 s12'>
				<h5 class='white-text'>Links</h5>
				<ul>
					<li><a class='grey-text text-lighten-3' href='javascript:void(0)'>Link 1</a></li>
					<li><a class='grey-text text-lighten-3' href='javascript:void(0)'>Link 2</a></li>
					<li><a class='grey-text text-lighten-3' href='javascript:void(0)'>Link 3</a></li>
					<li><a class='grey-text text-lighten-3' href='javascript:void(0)'>Link 4</a></li>
				</ul>
			</div>
		</div>
	</div>
-->		
<!--
		<div class='footer-copyright grey darken-4'>
		<div class='container'>© 2015 Bonobo, Inc. All rights reserved.
			<a class='grey-text text-lighten-4 right' href='javascript:void(0)'>Tentang Kami</a>
			<a class='grey-text text-lighten-4 right' href='".base_url('index/pp')."'>Kebijakan privasi</a>
			<a class='grey-text text-lighten-4 right' href='".base_url('index/tos')."'>Syarat dan ketentuan</a>
			
		</div>
	</div>
-->
					
					

	<div class='footer-copyright grey darken-4'>
		<div class='containermain'>
			<a class='grey-text text-lighten-3' href='javascript:void(0)'>Tentang Kami</a>
			<a class='grey-text text-lighten-3' href='".base_url('index/pp')."'>Kebijakan privasi</a>
			<a class='grey-text text-lighten-3' href='".base_url('index/tos')."'>Syarat dan ketentuan</a>
			<a href='http://www.bonoboapp.com' align='center'> © 2015 Bonobo, Inc. All rights reserved.</a>
		</div>		
	</div>

</footer>

<script type='text/javascript' src='".base_url("")."html/js/core.js'></script>
</body>
</html>
";
?>