<?php
class Error extends CI_Controller{
    function index(){
        $this->load->view('error');
    }
}
?>