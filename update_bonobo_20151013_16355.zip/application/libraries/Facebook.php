<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the facebook class */
require APPPATH."third_party/fb_sdk/facebook.php";

//class MY_Facebook {}